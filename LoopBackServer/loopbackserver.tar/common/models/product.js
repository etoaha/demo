module.exports = function(Product) {

};
